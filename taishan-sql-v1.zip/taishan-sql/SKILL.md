---
name: taishan-sql
description: Query Taishan database platform sources and run SQL through the bundled taishan-sql CLI. Use when users mention Taishan, 线上 SQL, 数据源查询, 慢 SQL 排查, 表容量分析, 大表治理, or need database reports from the JD Taishan DB platform.
---

# Taishan SQL

## Setup

This skill includes a bundled CLI under `scripts/cli`. If `taishan-sql` is unavailable, install it first:

```bash
bash scripts/install.sh
```

Then verify browser authentication:

```bash
taishan-sql doctor
```

If it returns `AUTH_UNAVAILABLE`, ask the user to log in to Taishan in Edge or Chrome, or set `TAISHAN_SQL_BROWSER`.

## Commands

- List authorized sources: `taishan-sql sources`
- Inspect a tree node: `taishan-sql children --id "<node-id>"`
- Resolve a database target: `taishan-sql resolve-db --keyword "<keyword>"`
- Query by resolved target: `taishan-sql query --keyword "<keyword>" --sql "<sql>"`
- Query by explicit target: `taishan-sql query --app-name "<app>" --domain "<domain>" --db-name "<db>" --sql "<sql>"`
- Use test environment: add `--env test` to `sources`, `children`, `resolve-db`, or `query`; omit it for production.

All commands print JSON. Treat `ok: false` as failure and inspect `error_code` and `message`.

## Workflow

For natural language database tasks:

1. Run `taishan-sql doctor`.
2. Resolve the database with `taishan-sql resolve-db --keyword "<keyword>"`.
3. If multiple matches are returned, ask the user to choose the intended database.
4. Run SQL with `taishan-sql query`.
5. Use returned `data.rows` and `data.execute_time_ms` to produce the answer or report.

For test environment work, keep the same `--env test` across discovery, resolving, and querying commands.

## Notes

- Browser cookies are read locally from Edge or Chrome; never ask the user to paste cookies into chat.
- Do not store cookie, token, or ticket values in repository files.
- The Taishan platform enforces SQL permissions. Still avoid destructive SQL unless the user explicitly requests it.
- Prefer small, targeted SQL and include `LIMIT` for exploratory queries.
