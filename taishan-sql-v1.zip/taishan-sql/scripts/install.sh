#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLI_DIR="${SCRIPT_DIR}/cli"

python -m pip install -e "${CLI_DIR}"

echo "taishan-sql installed. Run: taishan-sql doctor"
